﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Snake
{
    class Program
    {
        static void Main(string[] args)
        {
            

        }
    }

    public enum Directions
    {
        Left,
        Right,
        Up,
        Down
    }

    public class Point
    {
        public Point(int x, int y, char symbol)
        {
            this.X = x;
            this.Y = y;
            this.Symbol = symbol;
        }

        public int X { get; }
        public int Y { get; }
        public char Symbol { get; }

        public void Draw()
        {
            Console.SetCursorPosition(X, Y);
            Console.Write(Symbol);
        }

        public void Clear()
        {
            Console.SetCursorPosition(X, Y);
            Console.Write(" ");
        }

        public bool IsEqual(Point p)
        {
            if (this.X == p.X && this.Y == p.Y)
                return true;
            else
                return false;
        }
    }

    public class Walls
    {
        private List<Point> walls = new List<Point>();

        public List<Point> GetWalls => walls;

        public Walls(int width, int height)
        {
            for (int i = 0; i < width; i++)
            {
                Point topPoint = new Point(i, 0, '#');
                Point botPoint = new Point(i, height, '#');

                topPoint.Draw();
                botPoint.Draw();

                walls.AddRange(new List<Point>() { topPoint, botPoint });
            }

            for (int i = 0; i < height; i++)
            {
                Point leftPoint = new Point(0, i, '#');
                Point rightPoint = new Point(width, i, '#');

                leftPoint.Draw();
                rightPoint.Draw();

                walls.AddRange(new List<Point>() { leftPoint, rightPoint });
            }
        }  
    }

    public class FoodFactory
    {
        private int width;
        private int height;
        private Point currentFood;

        public Point CurrentFood => currentFood;

        public FoodFactory(int width, int height)
        {
            this.width = width;
            this.height = height;
        }

        public void Create()
        {
            Random rnd = new Random();

            int x = rnd.Next(1, width - 1);
            int y = rnd.Next(1, height - 1);

            Point food = new Point(x, y, '@');

            food.Draw();

            currentFood = food;
        }
    }

    public class Snake
    {
        private List<Point> body = new List<Point>();
        private Directions direction = Directions.Right;
        private bool canRotate = true;
        private bool isAlive = true;

        public Snake(int length, int width, int height)
        {
            for (int i = 0; i < length; i++)
            {
                Point bodyPart = new Point((width / 2) + i, height / 2, '■');
                body.Add(bodyPart);
                bodyPart.Draw();
            }
        }

        public Point Head => body.Last();
        public Point Tail => body.First();
        public bool IsAlive => isAlive;

        public void Move(bool clearTail = true)
        {
            Point newHead;

            switch (direction)
            {
                case Directions.Right:
                    newHead = new Point(Head.X + 1, Head.Y, '■');
                    break;
                case Directions.Left:
                    newHead = new Point(Head.X - 1, Head.Y, '■');
                    break;
                case Directions.Up:
                    newHead = new Point(Head.X, Head.Y + 1, '■');
                    break;
                case Directions.Down:
                    newHead = new Point(Head.X, Head.Y - 1, '■');
                    break;
                default:
                    goto case Directions.Right;
            }

            body.Add(newHead);
            Head.Draw();

            if (clearTail)
            {
                Tail.Clear();
                body.Remove(Tail);
            }

            canRotate = true;
        }

        public void Rotate(ConsoleKey key)
        {
            if (canRotate)
            {
                switch (direction)
                {
                    case Directions.Down:
                    case Directions.Up:
                        if (key == ConsoleKey.LeftArrow)
                        {
                            direction = Directions.Left;
                        }
                        else if (key == ConsoleKey.RightArrow)
                        {
                            direction = Directions.Right;
                        }
                        break;
                    case Directions.Right:
                    case Directions.Left:
                        if (key == ConsoleKey.UpArrow)
                        {
                            direction = Directions.Up;
                        }
                        else if (key == ConsoleKey.DownArrow)
                        {
                            direction = Directions.Down;
                        }
                        break;
                }

                canRotate = false;
            }
        }
    }

    public class Game
    {
        public static Timer timer;
        private static Walls walls = new Walls(400, 300);
        private static Snake snake = new Snake(3, 400, 300);
        private static FoodFactory foodFactory = new FoodFactory(400, 300);



        public static void Loop(object obj)
        {
            if (walls.GetWalls.Any(x => x.IsEqual(snake.Head)))
            {
                snake.IsAlive = false;
            }
        }
    }
}
